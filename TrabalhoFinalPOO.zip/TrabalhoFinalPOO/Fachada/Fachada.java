package TrabalhoFinalPOO.Fachada;

import TrabalhoFinalPOO.Excecoes.PontuacaoInvalidaException;
import TrabalhoFinalPOO.ClasseBasicas.Jogador;
import TrabalhoFinalPOO.Collection.Time;
import TrabalhoFinalPOO.Controle.*;
import TrabalhoFinalPOO.Excecoes.*;
import TrabalhoFinalPOO.Controle.Torneio;
import TrabalhoFinalPOO.Excecoes.JogadorInexistenteException;

import java.util.ArrayList;

/**
 * Classe responsável por intermediar o contato da gui com o backend, chamando a função das classes. Além disso, é um singleton
 * @author Gabriel
 */
public class Fachada {
    TrabalhoFinalPOO.Controle.Torneio torneio;
    // define o construtor como privado
    private static Fachada fachada;
    private Fachada(){
        torneio = new Torneio();
    }

    /**
     * singleton
     * @return A fachada criada como singleton
     */
    public static Fachada getInstance(){
        if(fachada == null){
            fachada = new Fachada();
        }
        return fachada;
    }

    /**
     * chama a função comecarTorneioAutomatico da classe  Torneio
     * @return A ArrayList com os finalistas
     * @throws TrabalhoFinalPOO.Excecoes.TimeIncompletoException Caso algum dos times esteja incompleto
     * @throws TrabalhoFinalPOO.Excecoes.TimeVazioException Caso alguns dos times esteja Vazio
     */
    public ArrayList<Time> comecarTorneioAutoMatico()throws TrabalhoFinalPOO.Excecoes.TimeIncompletoException, TrabalhoFinalPOO.Excecoes.TimeVazioException {
        try {
            return torneio.comecarTorneioAutoMatico();
        } catch (TimeIncompletoException e) {
            e.printStackTrace();
            throw new TimeIncompletoException();
        } catch (TimeVazioException e) {
            e.printStackTrace();
            throw new TimeVazioException();
        }
    }

    /**
     * chama a função comecarTorneioManual da classe  Torneio
     * @return A ArrayList com os finalistas
     * @throws TrabalhoFinalPOO.Excecoes.TimeIncompletoException Caso algum dos times esteja incompleto
     * @throws TrabalhoFinalPOO.Excecoes.TimeVazioException Caso alguns dos times esteja Vazio
     * @throws PontuacaoInvalidaException Caso a pontuação fornecida pelo usuário seja algo diferente de um núemro inteiro
     */
    public void comecarTorneioManual() throws TimeIncompletoException, TimeVazioException, PontuacaoInvalidaException {
        try {
            torneio.comecarTorneioManual();
        } catch (TimeIncompletoException e) {
            throw new TimeIncompletoException();
        } catch (TimeVazioException e) {
            throw new TimeVazioException();
        } catch (PontuacaoInvalidaException e) {
            throw new PontuacaoInvalidaException();
        }
    }

    /**
     * @return O total de times cadastrados
     */
    public int totalTimes(){
        return torneio.times.size();
    }
    /**
     * @return Uma ArrayList com os times cadastrados
     */
    public ArrayList<Time> getTimes(){
        return torneio.times;
    }

    /**
     * adiciona o time
     * @param time A ser adicionado e trata o fato de ele já ser está no time
     */
    public void adicionarTime(Time time)throws TimeJaExistenteException{
        try {
            torneio.cadastrarTime(time);
        } catch (TimeJaExistenteException e) {
            e.printStackTrace();
            throw new TimeJaExistenteException();
        }

    }

    /**
     * remove o time
     * @param nomeTime parametro com o nome do time a ser removido
     * @throws TrabalhoFinalPOO.Excecoes.TimeInexistenteException caso o time não exista
     */
    public void excluirTime(String nomeTime) throws TrabalhoFinalPOO.Excecoes.TimeInexistenteException {
        try {
            Time time = torneio.consultarTime(nomeTime);
            torneio.excluirTime(time);

        } catch (TrabalhoFinalPOO.Excecoes.TimeInexistenteException e) {
            throw new TrabalhoFinalPOO.Excecoes.TimeInexistenteException();
        }
    }
    //consulta o time

    /**
     * chama a classe Torneio para consultar se o time
     * @param nomeTime nome do time a ser procurado
     * @return o time procurado
     */
    public Time consultarTime(String nomeTime) throws TimeInexistenteException{
        try {
            return torneio.consultarTime(nomeTime);
        } catch (TrabalhoFinalPOO.Excecoes.TimeInexistenteException e) {
            e.printStackTrace();
            throw new TimeInexistenteException();
        }
    }

    /**
     * Cadastra um jogado ao time passado como parâmetro
     * @param time time passado como parametro
     * @param jogador joagador a ser cadastrado
     * @throws TrabalhoFinalPOO.Excecoes.TimeCompletoException caso o time esteja completo
     */
    public void cadastrarJogador(String time, Jogador jogador) throws TrabalhoFinalPOO.Excecoes.TimeCompletoException {
        Time consultando = null;
        try {
            consultando = consultarTime(time);
            if(consultando.getNumeroJogadores() == 2){
                throw new TrabalhoFinalPOO.Excecoes.TimeCompletoException();
            }else{
                consultando.cadastrarJogador(jogador);
            }
        } catch (TimeInexistenteException e) {
            e.printStackTrace();
        }

    }

    /**
     * verifica a qual time um jogador pertence
     * @param id do jogador
     * @return o time ao qual o jogador pertence
     * @throws JogadorInexistenteException caso o jogador não pertencça a nenhum time
     */
    public Time jogadorPertenceTime(int id) throws JogadorInexistenteException {
        try {
            return torneio.jogadorPertenceTime(id);
        } catch (JogadorInexistenteException e) {
            throw new JogadorInexistenteException();
        }
    }

    /**
     * procura um jogador no ArrayList de times
     * @param id do jogador a ser procurado
     * @return o Jogador
     * @throws TrabalhoFinalPOO.Excecoes.JogadorInexistenteException caso o jogador não pertença a nenhum time
     */
    public Jogador consultarJogador(int id) throws TrabalhoFinalPOO.Excecoes.JogadorInexistenteException {
        try {
            return torneio.consultarJogador(id);
        } catch (JogadorInexistenteException e) {
            throw new JogadorInexistenteException();
        }
    }

    /**
     * exclui um jogador
     * @param id do jogador a ser exlucido
     * @throws TrabalhoFinalPOO.Excecoes.JogadorInexistenteException caso o jogador não pertença a nenhum time
     */
    public void excluirJogador(int id) throws TrabalhoFinalPOO.Excecoes.JogadorInexistenteException {
        try {
            Jogador jogador = this.consultarJogador(id);
            this.jogadorPertenceTime(id).excluirJogador(jogador);
        } catch ( TrabalhoFinalPOO.Excecoes.TimeVazioException | TrabalhoFinalPOO.Excecoes.JogadorInexistenteException e) {
            e.printStackTrace();
            throw new JogadorInexistenteException();
        }

    }
}
