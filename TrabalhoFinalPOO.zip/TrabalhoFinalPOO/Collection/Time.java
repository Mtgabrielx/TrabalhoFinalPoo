package TrabalhoFinalPOO.Collection;

import TrabalhoFinalPOO.ClasseBasicas.Jogador;
import TrabalhoFinalPOO.Excecoes.*;

import java.util.ArrayList;

/**
 * Classe responsável por implementar as ações que
 * podem ser feitas no time, bem como implementa uma
 * ArrayList de Jogadores
 * @author Gabriel
 */

public class Time {

    // gera o ArrayList de jogadores que compoem o time
    // que é limitado a duas pessoas
    public ArrayList<Jogador> listaJogadores= new ArrayList<Jogador>();

    // armazena o nome do time
    private String nome;

    // armazena o valor dos pontos finais da ultima partida, para que depois seja gerado um arquivo.txt com
    // as informações do time campeão e sua pontuação
    private int pontosJogoFinal;

    /**
     * Construtor de Time
     * @param nome
     */
    public Time(String nome){
        this.setNome(nome);
    } // fim do Construtor Time

    /**
     * Cadastra um jogador ao time
     * @param novato O jogador a ser inserido no time
     * @throws TimeCompletoException Se o time já estiver completo
     */
    public void cadastrarJogador(Jogador novato) throws TimeCompletoException {
        if(listaJogadores.size() == 2){
            throw new TimeCompletoException();
        }
        else{
            if(this.validarJogador(novato)){
                listaJogadores.add(novato);
            }
        }
    }

    /**
     * procura por um jogador pelo seu id, caso o time esteja vazio ou o jogador nao exista, ele chama uma
     * @param id O id do jogador que se deseja achar
     * @return um Jogador com o id procurado
     * @throws TimeVazioException No caso do time está vazio
     */
    public Jogador consultarJogador(int id) throws TimeVazioException {
        if(listaJogadores.isEmpty()){
            throw new TimeVazioException();
        }
        for(int i=0; i < listaJogadores.size(); i++){
            if( id == listaJogadores.get(i).getId()){
                return listaJogadores.get(i);
            }
        }
        return null;
    }

    /**
     * Exclui um jogador do time
     * @param deSaida Jogador que deseja remover
     * @throws JogadorInexistenteException Caso o jogador não exista no time
     * @throws TimeVazioException Caso o time esteja vazio
     */
    public void excluirJogador(Jogador deSaida) throws JogadorInexistenteException, TimeVazioException{
        if(listaJogadores.isEmpty()){
            throw new TimeVazioException();
        }
        if(listaJogadores.contains(deSaida)){
            listaJogadores.remove(deSaida);
        }
        else{
            throw new JogadorInexistenteException();
        }

    }

    /**
     * verifica se um mesmo jogador ja existe no time, caso ele nao exista, ele eh valido para entrar
     * @param jogador recebe o jogador a ser procurado
     * @return Um booleano afirmativo caso ele possa ser adicionado ao time e negativo caso ele já exista no time
     */

    public boolean validarJogador(Jogador jogador){
        boolean valido = true;
        if(listaJogadores.contains(jogador)){
            valido = false;
        }
        return valido;
    }

    /**
     * Coloca todas as caracteristica de um time, bem como as informações dos jogadores, em um String
     * @return Retorna a String com as informações dos jogadores e do time
     */

    public String apresentar(){
        String conteudo = ( "Time : "+ this.getNome() + ", pontos no jogo final: " +
                this.getPontosJogoFinal() + "\n");
        for(Jogador jogador: listaJogadores){
            conteudo += jogador.toString();
            conteudo += "\n";
        }
        return conteudo;
    }

    /**
     * calcula o total de pontos obtido em um jogo de acordo com o alvo acertado pelo jogador
     * @return A soma dos pontos obtidos por cada jogador
     * @throws TimeVazioException Caso o time esteja sem jogadores
     */
    public int pontosObtidos() throws TimeVazioException{
        int pontos = 0;

        if(listaJogadores.isEmpty()){
            throw new TimeVazioException();
        }

        for(Jogador jogador: listaJogadores){ //cada jogador atira e a partir desse valor, é possível chegar a
            //quantidade de pontos que ele conseguiu com aquela tentativa
            double resultado = jogador.atirar();
            if(resultado < 1){
                pontos += pontos;
            }
            else if( resultado < 2){
                pontos += pontos + 1;
            }
            else if( resultado < 4){
                pontos += pontos + 3;
            }
            else if( resultado < 6){
                pontos += pontos + 5;
            }
            else if( resultado < 9){
                pontos += pontos + 7;
            }
            else{
                pontos += pontos + 10;
            }
        }
        setPontosJogoFinal(pontosJogoFinal);
        return pontos;
    }

    public int getPontosJogoFinal() {
        return pontosJogoFinal;
    }

    public void setPontosJogoFinal(int pontosJogoFinal) {
        this.pontosJogoFinal = pontosJogoFinal;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public ArrayList<Jogador> getListaJogadores() {
        return listaJogadores;
    }

    public int getNumeroJogadores() {
        return listaJogadores.size();
    }
}
