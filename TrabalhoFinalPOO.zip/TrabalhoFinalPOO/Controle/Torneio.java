package TrabalhoFinalPOO.Controle;

import TrabalhoFinalPOO.ClasseBasicas.Jogador;
import TrabalhoFinalPOO.Collection.Time;
import TrabalhoFinalPOO.Excecoes.*;
import TrabalhoFinalPOO.Gui.TabelaTorneioManual;

import javax.swing.*;
import java.io.*;
import java.util.ArrayList;

/**
 * Classe responsável por controlar o torneio, seja adicionando, consultando ou excluindo times e jogadores
 * bem como é responsável por iniciar tanto o torneio manual quanto o torneio automático
 * @author Gabriel
 */

public class Torneio {
    //ArrayList com todos os times de um torneio
    public ArrayList<Time> times= new ArrayList<Time>();

    /**
     * Cadastra um time ao torneio
     * @param novo Recebe o time a cadastrar
     * @throws TrabalhoFinalPOO.Excecoes.TimeJaExistenteException Caso o time a ser cadastrado já exista
     */
    public void cadastrarTime(Time novo) throws TrabalhoFinalPOO.Excecoes.TimeJaExistenteException {
        for(Time time: times){
            if(time.getNome().equals(novo.getNome())){
                throw new TimeJaExistenteException();
            }
        }

        times.add(novo);

    }

    /**
     * Exclui um time do torneio
     * @param time recebe o time a ser excluido
     * @throws TrabalhoFinalPOO.Excecoes.TimeInexistenteException Caso o time a ser excluido não exista no torneio
     */
    public void excluirTime(Time time) throws TrabalhoFinalPOO.Excecoes.TimeInexistenteException {
        if(times.contains(time)){
            times.remove(time);
        }else{
            throw new TrabalhoFinalPOO.Excecoes.TimeInexistenteException();
        }

    }

    /**
     * consulta se um time esta cadastrado no torneio
     * @param procurando Passa o nome do time a ser procurado no torneio
     * @return O time procurado
     * @throws TrabalhoFinalPOO.Excecoes.TimeInexistenteException Caso o time procurado não exista
     */
    public Time consultarTime(String procurando) throws TrabalhoFinalPOO.Excecoes.TimeInexistenteException {
        for(Time time: times){
            if(time.getNome().equals(procurando)){
                return time;
            }
        }
        throw new TrabalhoFinalPOO.Excecoes.TimeInexistenteException();
    }

    /**
     * Verifica a qual time pertence um jogador com um dado id
     * @param id Int com o id do jogador
     * @return O time a qual o jogador pertence
     * @throws JogadorInexistenteException Caso o jogador não pertença a nenhum dos times
     */
    public Time jogadorPertenceTime(int id) throws JogadorInexistenteException{
        for(Time time: times){
            try {
                Jogador jogador = time.consultarJogador(id);
                if(jogador != null && jogador.getId() == id){
                    return time;
                }
            } catch (TimeVazioException ignored) { }
        }

        throw new JogadorInexistenteException();

    }

    /**
     * procura um jogador com um dado id e retorna aquele jogador
     * @param id do jogador a ser procurado
     * @return O jogador com o id passado
     * @throws TrabalhoFinalPOO.Excecoes.JogadorInexistenteException Caso o jogador não seja encontrado
     */
    public Jogador consultarJogador(int id) throws TrabalhoFinalPOO.Excecoes.JogadorInexistenteException {
        for(Time time: times){
            try {
                Jogador jogador = time.consultarJogador(id);
                if( jogador!= null && jogador.getId() == id){
                    return jogador;
                }
            } catch (TrabalhoFinalPOO.Excecoes.TimeVazioException ignored) {
            }
        }
        throw new TrabalhoFinalPOO.Excecoes.JogadorInexistenteException();
    }


    /**
     * começa o torneio, assim, é criada uma copia dos times cadastrados, e , até os 4 finalistas, é apagado
     * os que perderam e repostos os que ganharam, os valores das vitórias são obtidos de forma automatica,
     * quando chega nos 4 finalistas, é feita uma partida com os dois primeiros e o que perdeu é coloca no final
     * da lista, depois é feita uma partida entre o 2 e o 3 do array, o que perdeu é colocado no final. Assim,
     * esse processo é repetido mais 1 vez resultando em um array ordenado, com o 1 lugar na primeira posição
     * e o 4 na ultima. Por fim, ele gera um arquivo dando informacoes sobre o ganhador.
     * @return A lista com os times campeões, ordenados, sendo o primeiro da lista o primeiro lugar e o ultimo o quarto lugar
     * @throws TimeIncompletoException Caso algum dos times esteja incompleto
     * @throws TimeVazioException Caso algum dos times esteja vazio
     */
    public ArrayList<Time> comecarTorneioAutoMatico() throws TimeIncompletoException, TimeVazioException {
        // clona a ArrayList dos times cadastrados no torneio
        ArrayList<Time> finalistas = (ArrayList<Time>) times.clone();

        // repete até a lista finalistas ter somente 4 times.
        while (finalistas.size()!=4){
            // armazena os time para depois remove-los da lista
            Time primeiro = finalistas.get(0);
            Time segundo = finalistas.get(1);
            if(primeiro.getListaJogadores().isEmpty() || segundo.getListaJogadores().isEmpty()){
                throw new TrabalhoFinalPOO.Excecoes.TimeVazioException();
            }

            if(primeiro.getListaJogadores().size() < 2 || segundo.getListaJogadores().size() < 2){
                throw new TimeIncompletoException();
            }
            finalistas.remove(primeiro);
            finalistas.remove(segundo);

            JOptionPane.showMessageDialog(null, ( primeiro.getNome() + " Vs " + segundo.getNome()),
                    "Partida", JOptionPane.INFORMATION_MESSAGE);

            // consegue a pontuação dos times
            int pontuacaoPrimeiro = primeiro.pontosObtidos();
            int pontuacaoSegundo = segundo.pontosObtidos();
            if(pontuacaoPrimeiro > pontuacaoSegundo){
                finalistas.add(primeiro);
                JOptionPane.showMessageDialog(null,
                        ( primeiro.getNome() ) , "Vencedor",
                        JOptionPane.INFORMATION_MESSAGE);
            }
            else{
                finalistas.add(segundo);
                JOptionPane.showMessageDialog(null,
                        ( segundo.getNome() ) , "Vencedor",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        }

        // repete 4 vezes e organiza a lista
        for(int i=0; i < 4; i++){
            Time primeiro = finalistas.get(0);
            Time segundo = finalistas.get(1);
            if(i%2!=0){
                primeiro = finalistas.get(1);
                segundo = finalistas.get(2);

            }
            int pontuacaoPrimeiro = primeiro.pontosObtidos();
            int pontuacaoSegundo = segundo.pontosObtidos();

            // muda a menssagem a ser exibida
            if(i==2){
                JOptionPane.showMessageDialog(null,
                        ( primeiro.getNome() + " Vs " + segundo.getNome()) , "Final",
                        JOptionPane.INFORMATION_MESSAGE);
            }
            else{
                JOptionPane.showMessageDialog(null,
                        ( primeiro.getNome() + " Vs " + segundo.getNome()) , "Semi-Final",
                        JOptionPane.INFORMATION_MESSAGE);
            }

            if(i==3){
                // coloca o times perdedores no final da lista
                if(pontuacaoPrimeiro > pontuacaoSegundo){
                    finalistas.remove(primeiro);
                    finalistas.add(primeiro);
                    finalistas.remove(segundo);
                    finalistas.add(segundo);
                    JOptionPane.showMessageDialog(null,
                            ( primeiro.getNome() ) , "Vencedor",
                            JOptionPane.INFORMATION_MESSAGE);
                }
                else{
                    finalistas.remove(segundo);
                    finalistas.add(segundo);
                    finalistas.remove(primeiro);
                    finalistas.add(primeiro);
                    JOptionPane.showMessageDialog(null,
                            ( segundo.getNome() ) , "Vencedor",
                            JOptionPane.INFORMATION_MESSAGE);
                }
            }else{
                // organiza a posição do 3° e 4° lugares na lista
                if(pontuacaoPrimeiro > pontuacaoSegundo){
                    finalistas.remove(segundo);
                    finalistas.add(segundo);
                    JOptionPane.showMessageDialog(null,
                            ( primeiro.getNome() ) , "Vencedor",
                            JOptionPane.INFORMATION_MESSAGE);
                }
                else{
                    finalistas.remove(primeiro);
                    finalistas.add(primeiro);
                    JOptionPane.showMessageDialog(null,
                            ( segundo.getNome() ) , "Vencedor",
                            JOptionPane.INFORMATION_MESSAGE);
                }
            }
        }

        // cria um Arquivo.txt com as informações do time vencendor
        File file = new File("Arquivo.txt");
        try {
            FileWriter fw = new FileWriter(file);
            BufferedWriter bw = new BufferedWriter(fw);  //classe otimizada de escrita

            bw.write("Informações do time campeão");
            bw.newLine();
            String stringCampeao = finalistas.get(0).apresentar();
            bw.write(stringCampeao);
            bw.flush();
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return finalistas;
    }

    /**
     * Chama a classe TabelaTorneioManual que organiza um torneio manual
     * @throws TimeIncompletoException Caso algum dos times esteja incompleto
     * @throws TimeVazioException Caso algum time esteja vazio
     * @throws PontuacaoInvalidaException Caso a pontuação fornecida pelo usuário seja inválida, ou seja, tenha algo diferente de números
     */
    public void comecarTorneioManual() throws TimeIncompletoException, TimeVazioException, PontuacaoInvalidaException {
        ArrayList<Time> finalistas = (ArrayList<Time>) times.clone();
        try {
            new TabelaTorneioManual(finalistas);
        } catch (PontuacaoInvalidaException e) {
            throw new PontuacaoInvalidaException();
        } catch (TimeIncompletoException e) {
            throw new TimeIncompletoException();
        } catch (TimeVazioException e) {
            throw new TimeVazioException();
        }
    }
}
