package TrabalhoFinalPOO.Excecoes;

public class JogadorJaExistenteException extends Exception{
    public JogadorJaExistenteException(){
        super("Jogador Já Existente");
    }
}

