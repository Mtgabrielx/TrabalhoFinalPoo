package TrabalhoFinalPOO.Excecoes;

public class TimeInexistenteException extends Exception{
    public TimeInexistenteException(){
        super("Time Inexistente");
    }
}
