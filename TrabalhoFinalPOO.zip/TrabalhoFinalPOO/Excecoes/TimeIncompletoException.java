package TrabalhoFinalPOO.Excecoes;

public class TimeIncompletoException extends Exception {
    public TimeIncompletoException(){
        super("Time incompleto!!");
    }
}
