package TrabalhoFinalPOO.Excecoes;

public class PontuacaoInvalidaException extends Exception{
	
	    public PontuacaoInvalidaException(){
	        super("Pontuação Inválida");
	    }


}
