package TrabalhoFinalPOO.Excecoes;

public class TimeCompletoException extends Exception{
    public TimeCompletoException(){
        super("Time Completo");
    }
}

