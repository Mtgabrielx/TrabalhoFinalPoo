package TrabalhoFinalPOO.Excecoes;

public class TimeJaExistenteException extends Exception{
    public TimeJaExistenteException(){
        super("Time Já Existente");
    }
}