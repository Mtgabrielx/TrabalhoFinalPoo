package TrabalhoFinalPOO.Excecoes;

public class PrescisaoInvalidaException extends Exception{
    public PrescisaoInvalidaException(){
        super("Prescisão invalida!");
    }

}
