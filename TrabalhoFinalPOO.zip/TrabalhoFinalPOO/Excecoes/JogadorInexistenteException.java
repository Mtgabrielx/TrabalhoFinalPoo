package TrabalhoFinalPOO.Excecoes;

public class JogadorInexistenteException extends Exception{
    public JogadorInexistenteException(){
        super("Jogador Inexistente");
    }
}
