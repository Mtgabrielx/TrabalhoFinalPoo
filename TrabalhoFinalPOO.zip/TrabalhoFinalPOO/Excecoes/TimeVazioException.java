package TrabalhoFinalPOO.Excecoes;

public class TimeVazioException extends Exception{
    public TimeVazioException(){
        super("Time Vazio");
    }
}

