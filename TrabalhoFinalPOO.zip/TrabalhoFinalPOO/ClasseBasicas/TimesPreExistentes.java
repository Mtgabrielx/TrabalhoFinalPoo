package TrabalhoFinalPOO.ClasseBasicas;

import TrabalhoFinalPOO.Collection.Time;
import TrabalhoFinalPOO.Excecoes.*;
/**
 * Classe para implementar os Times pre-existentes para rodar um campeonato
 * @author jlucas
 */
public class TimesPreExistentes {
    /**
     * classe para retornar o time pre-existente Amarelo
     * @return Time - time Amarelo
     * @throws TimeCompletoException, caso o time esteja completo
     */
    public static Time getTimeAmarelo(){
        Time timeAmarelo = new Time("timeAmarelo");
        Jogador amarelo01 = new Jogador("Amarelo01",901,0.67,false);
        Jogador amarelo02 = new Jogador("amarelo02",902,0.47,false);
        try {
            timeAmarelo.cadastrarJogador(amarelo01);
            timeAmarelo.cadastrarJogador(amarelo02);
            return timeAmarelo;
        } catch (TimeCompletoException e) {
            e.printStackTrace();
        }
        return timeAmarelo;

    }
    /**
     * classe para retornar o time pre-existente Cinza
     * @return Time - time cinza
     * @throws TimeCompletoException, caso o time esteja completo
     */
    public static Time getTimeCinza(){
        Time timeCinza = new Time("timeCinza");
        Jogador cinza1 = new Jogador("Cinza01",903,0.68,false);
        Jogador cinza02 = new Jogador("Cinza02",904,0.87,false);
        try {
            timeCinza.cadastrarJogador(cinza1);
            timeCinza.cadastrarJogador(cinza02);
            return timeCinza;
        } catch (TimeCompletoException e) {
            e.printStackTrace();
        }
        return timeCinza;
    }
//
    /**
     * classe para retornar o time pre-existente Laranja
     * @return Time - time Laranja
     * @throws TimeCompletoException, caso o time esteja completo
     */
    public static Time getTimeLaranja(){
        Time timeLaranja = new Time("timeLaranja");
        Jogador laranja1 = new Jogador("Laranja01",905,0.68,false);
        Jogador laranja02 = new Jogador("Laranja02",906,0.87,false);
        try {
            timeLaranja.cadastrarJogador(laranja1);
            timeLaranja.cadastrarJogador(laranja02);
            return timeLaranja;
        } catch (TimeCompletoException e) {
            e.printStackTrace();
        }
        return timeLaranja;
    }
    /**
     * classe para retornar o time pre-existente Azul
     * @return Time - time Azul
     * @throws TimeCompletoException, caso o time esteja completo
     */
    public static Time getTimeAzul(){
        Time timeAzul = new Time("timeAzul");
        Jogador azul1 = new Jogador("Azul01",907,0.64,false);
        Jogador azul02 = new Jogador("Azul02",908,0.85,false);
        try {
            timeAzul.cadastrarJogador(azul1);
            timeAzul.cadastrarJogador(azul02);
            return timeAzul;
        } catch (TimeCompletoException e) {
            e.printStackTrace();
        }
        return timeAzul;
    }

    /**
     * classe para retornar o time pre-existente Real
     * @return Time - time Real
     * @throws TimeCompletoException, caso o time esteja completo
     */
    public static Time getTimeReal(){
        Time timeReal = new Time("timeReal");
        Jogador real1 = new Jogador("Real01",909,0.59,false);
        Jogador real02 = new Jogador("Real02",910,0.71,false);
        try {
            timeReal.cadastrarJogador(real1);
            timeReal.cadastrarJogador(real02);
            return timeReal;
        } catch (TimeCompletoException e) {
            e.printStackTrace();
        }
        return timeReal;
    }

    /**
     * classe para retornar o time pre-existente Vasco
     * @return Time - time Vasco
     * @throws TimeCompletoException, caso o time esteja completo
     */
    public static Time getTimeVasco(){
        Time timeVasco = new Time("timeVasco");
        Jogador vasco1 = new Jogador("Vasco01",911,0.64,false);
        Jogador vasco02 = new Jogador("Vasco02",912,0.77,false);
        try {
            timeVasco.cadastrarJogador(vasco1);
            timeVasco.cadastrarJogador(vasco02);
            return timeVasco;
        } catch (TimeCompletoException e) {
            e.printStackTrace();
        }
        return timeVasco;
    }

    /**
     * classe para retornar o time pre-existente Verde
     * @return Time - time Verde
     * @throws TimeCompletoException, caso o time esteja completo
     */
    public static Time getTimeVerde(){
        Time timeVerde = new Time("timeVerde");
        Jogador verde1 = new Jogador("Verde01",913,0.69,false);
        Jogador verde02 = new Jogador("Verde02",914,0.78,false);
        try {
            timeVerde.cadastrarJogador(verde1);
            timeVerde.cadastrarJogador(verde02);
            return timeVerde;
        } catch (TimeCompletoException e) {
            e.printStackTrace();
        }
        return timeVerde;
    }

    /**
     * classe para retornar o time pre-existente Vermelho
     * @return Time - time Vermelho
     * @throws TimeCompletoException, caso o time esteja completo
     */
    public static Time getTimeVermelho(){
        Time timeVermelho = new Time("timeVermelho");
        Jogador vermelho1 = new Jogador("Vermelho01",915,0.77,false);
        Jogador vermelho02 = new Jogador("Vermelho02",916,0.85,false);
        try {
            timeVermelho.cadastrarJogador(vermelho1);
            timeVermelho.cadastrarJogador(vermelho02);
            return timeVermelho;
        } catch (TimeCompletoException e) {
            e.printStackTrace();
        }
        return timeVermelho;
    }

}

