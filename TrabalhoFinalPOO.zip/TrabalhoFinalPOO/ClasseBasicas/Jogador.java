package TrabalhoFinalPOO.ClasseBasicas;
/**
 * Classe para representação de objetos do tipo Jogador, onde serão implementados os métodos
 * de sets e gets do parâmetros da classe e as ações de atirar e lesionar-se
 * @author jlucas
 */
public class Jogador {
    private String nome;
    private int id;
    private double precisao, lesao;
    private boolean lesionado;
    /**
     * Construtor  do jogador do torneio
     * @param nome
     * @param id
     * @param precisao
     * @param lesionado
     */
    public Jogador(String nome, int id, double precisao, boolean lesionado){
        this.setNome(nome);
        this.setId(id);
        this.setPrecisao(precisao);// valor entre [0,1]
        this.setLesionado(lesionado);
    }
    /**
     * Método para trabalhar a chance de um jogador se lesionar
     * ativa o status de lesionado
     */
    private void podeLesionar(){
        double lesaoDebuff = Math.random();
        // a lesao causa uma diminuicao de precisao maxima de 0.2 no método atirar
        if(lesaoDebuff* 10 <= 2){
            this.lesionado = true;
            this.setLesao(lesaoDebuff);
        }
    }


    /**
     * Método que roda o valor da pontuação obtida pelo jogador ao atirar, trabalha com uma aleatoriedade e com a precisão,
     * verifica se o jogador está lesionado para considerar essa diminuição no valor final
     * @return double - valor da pontuação adquirida
     */
    public double atirar(){
        double casualidade = Math.random();
        // o acerto dele é calculado como a precisao dele multiplicada por 0.7 e somada a um numero aleatorio entre
        // 0 e 1 multiplicado por 0.3. No final tudo é multiplicado por 10 e esse número é arredondado para cima e retornado
        // como resultado
        if(lesionado){
            return ( (casualidade*0.3+ precisao*0.7) * 10 - lesao ); // caso ele esteja machucado a lesao diminui sua
            // precisao, note que a lesao eh um numero entre 0 e 1
        }
        else{
            this.podeLesionar();
            return ( (casualidade*0.3+ precisao*0.7) * 10 ); // caso ele nao esteja machucado, ele atira normalmente
            // contudo fica lesionado posteriormente
        }
    }

    /**
     * Método para apresentar o jogador com o uso to toString
     * @return
     */
    // apresentacao do jogador
    public String toString(){
        String apresentacao;
        if(this.isLesionado()){
            apresentacao = ("Nome: " + this.getNome()+ ", ID: " + this.id + ", prescisao: " +
                    getPrecisao() + ", lesionado: sim");
        }
        else{
            apresentacao = ("Nome: " + this.getNome()+ ", ID: " + this.id + ", prescisao: " +
                    getPrecisao() + ", lesionado: não");
        }
        return apresentacao;
    }
    /**
     * método para retornrar o nome do jogador
     * @return String - Nome do jogador
     */
    public String getNome() {
        return nome;
    }
    /**
     * método para setar o nome do jogador
     * @param nome
     */
    public void setNome(String nome) {
        this.nome = nome;
    }
    /**
     * método para retornar a identificação do jogador
     * @return int - identificação do jogador
     */
    public int getId() {
        return id;
    }
    /**
     * método para setar a identificação do jogador
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }
    /**
     * método para retorno da precisão do jogador
     * @return double - Precisão do jogador
     */
    public double getPrecisao() {
        return precisao;
    }
    /**
     * método para setar a precisão
     * @param precisao
     */
    public void setPrecisao(double precisao) {
        this.precisao = precisao;
    }
    /**
     * método para setar a chance de lesão
     * @param chanceLesionar
     */
    public void setLesao(double chanceLesionar) {
        this.lesao = chanceLesionar;
    }
    /**
     * método para retorno do status de lesionado
     * @return boolean - lesionado
     */
    public boolean isLesionado() {
        return lesionado;
    }
    /**
     * método para setar o status de lesionado
     * @param lesionado
     */
    public void setLesionado(boolean lesionado) {
        this.lesionado = lesionado;
    }
}
