package TrabalhoFinalPOO.Gui;

import TrabalhoFinalPOO.Collection.Time;

import javax.swing.*;
import java.awt.*;

/**
 * GUI para a Tabela Time.
 * Cria uma tabela 3x5 com os jogadores do time referente,
 * indicada as informações dos dois jogadores do time
 * @Amauri
 */

public class TabelaTime extends JFrame {

    //tabela usada para exibir as informacoes de um time
    public TabelaTime(Time time){
    	getContentPane().setBackground(new Color(245, 245, 220));
        String[] titulos = {"Nome do jogador", "ID ", "Prescisão", "Lesionado"};
        String[][] valores = new String[2][4];

            for(int i=0; i < time.listaJogadores.size(); i++){
                valores[i][0] = time.listaJogadores.get(i).getNome();
                valores[i][1] = String.valueOf(time.listaJogadores.get(i).getId());
                valores[i][2] = String.valueOf(time.listaJogadores.get(i).getPrecisao());
                if(time.listaJogadores.get(i).isLesionado()) {
                	valores[i][3] = "Sim";
                }
                if(!time.listaJogadores.get(i).isLesionado()) {
                	valores[i][3] = "Não";
                }
            }

            JTable tabela = new JTable(valores,titulos);
            tabela.setBackground(new Color(255, 255, 224));
            setTitle(time.getNome());
            JScrollPane paneTabela = new JScrollPane(tabela);
            getContentPane().setLayout(new FlowLayout());
            getContentPane().add(paneTabela);
            this.setSize(500,97);
            setBounds(700, 200, 500, 97);
            this.setVisible(true);	
            setResizable(false);

    }
}


