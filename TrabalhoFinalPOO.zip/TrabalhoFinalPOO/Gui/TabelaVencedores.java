package TrabalhoFinalPOO.Gui;

import TrabalhoFinalPOO.Collection.*;
import TrabalhoFinalPOO.Collection.Time;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.*;
import java.awt.*;

public class TabelaVencedores extends JFrame {

    /**
     * GUI para a Tabela dos Vencedores, do primero ao quarto colocado.
     * Primeiramente inicia-se um GIF representando o torneio e um carregamento,
     * em seguida o tamanho da janela é alterado e o GIF é deixado invisível, assim,
     * mostrando a tabela dos vencedores quando o timer acaba e inicia essa ação
     * @param times Uma ArrayList com os times finalistas
     * @Amauri
     */
    public TabelaVencedores(ArrayList<Time> times){

        Icon icon = new ImageIcon(getClass().getResource("/TrabalhoFinalPOO/Gui/archer.gif"));
        JLabel label = new JLabel(icon);

        getContentPane().add(label);
        label.setVisible(true);

        getContentPane().setBackground(new Color(245, 245, 220));
        String[] titulos = {"Colocação", "Nome do time"};
        String[][] valores = new String[4][3];

        for(int i=0; i < times.size(); i++){
            valores[i][0] = String.valueOf(i+1);
            valores[i][1] = times.get(i).getNome();
        }

        JTable tabela = new JTable(valores,titulos);
        tabela.setBackground(new Color(255, 255, 224));
        JScrollPane paneTabela = new JScrollPane(tabela);
        getContentPane().setLayout(new FlowLayout());
        getContentPane().add(paneTabela);
        this.setSize(500,270);
        setBounds(700, 297, 500, 270);
        setTitle("Carregando");
        setVisible(true);
        setResizable(false);
        Timer cronometro = new Timer();
        TimerTask tarefa = new TimerTask() {
            @Override
            public void run() {
                setTitle("Vencedores");
                label.setVisible(false);
                setSize(500,129);
                setBounds(700, 297, 500, 129);
            }
        };
        int milissegundos = 3400;
        cronometro.schedule(tarefa, milissegundos);


    }
}
