package TrabalhoFinalPOO.Gui;

import TrabalhoFinalPOO.Excecoes.PontuacaoInvalidaException;
import TrabalhoFinalPOO.Collection.Time;
import TrabalhoFinalPOO.Excecoes.TimeIncompletoException;
import TrabalhoFinalPOO.Excecoes.TimeVazioException;

import javax.swing.*;
import java.io.*;
import java.util.ArrayList;

public class TabelaTorneioManual {
    /**
     * cria um pop up que informa quais times estão jogando e pede a informação da pontuação deles
     * depois elimina aqueles com a menor pontuação
     * @param finalistas Recebe uma lista com os participantes do torneio
     * @throws TimeVazioException Caso algum time esteja vazio
     * @throws TimeIncompletoException Caso algum time esteja incompleto
     * @throws PontuacaoInvalidaException Caso a pontuação passada não seja composta somente por números
     */
    public TabelaTorneioManual(ArrayList<Time> finalistas) throws TimeVazioException, TimeIncompletoException,PontuacaoInvalidaException {
        /**
         * começa o torneio, assim, é criada uma copia dos times cadastrados, e , até os 4 finalistas, é apagado
         * os que perderam e repostos os que ganharam, a pontuação é definida pelo usuário, quando chega nos
         * 4 finalistas, é feita uma partida com os dois primeiros e o que perdeu é coloca no final da lista,
         * depois é feita uma partida entre o 2 e o 3 do array, o que perdeu é colocado no final. Assim,
         * esse processo é repetido mais 1 vez resultando em um array ordenado, com o 1 lugar na primeira
         * posição e o 4 na ultima. Por fim, ele gera um arquivo dando informacoes sobre o ganhador
         * @return A lista com os times campeões, ordenados, sendo o primeiro da lista o primeiro lugar e o ultimo o quarto lugar
         * @throws TimeIncompletoException Caso algum dos times esteja incompleto
         * @throws TimeVazioException Caso algum dos times esteja vazio
         */

        for(Time times: finalistas){
            //verifica se os times estão vazio
            if(times.getListaJogadores().isEmpty()){
                throw new TrabalhoFinalPOO.Excecoes.TimeVazioException();
            }

            //verifica se falta jogadores
            if(times.getListaJogadores().size() < 2){
                throw new TimeIncompletoException();
            }
        }
        while (finalistas.size()!=4){
            // armazena os time para depois remove-los da lista
            Time primeiro = finalistas.get(0);
            Time segundo = finalistas.get(1);

            finalistas.remove(primeiro);
            finalistas.remove(segundo);

            JOptionPane.showMessageDialog(null,
                    ( primeiro.getNome() + " Vs " + segundo.getNome()) , "Partida",
                    JOptionPane.INFORMATION_MESSAGE);

            try {
                // consegue a pontuação
                int pontuacaoPrimeiro = getPontuacao(primeiro);
                int pontuacaoSegundo = getPontuacao(segundo);

                // faz os times competirem até obterem uma ponutação diferente uma do outro
                if(pontuacaoPrimeiro == pontuacaoSegundo) {
                    while(pontuacaoPrimeiro == pontuacaoSegundo) {
                        pontuacaoPrimeiro = getPontuacao(primeiro);
                        pontuacaoSegundo = getPontuacao(segundo);
                    }
                }
                // elimina o time com menor ponutação
                if(pontuacaoPrimeiro > pontuacaoSegundo){
                    finalistas.add(primeiro);
                    JOptionPane.showMessageDialog(null,
                            (primeiro.getNome()) , "Vencedor",
                            JOptionPane.INFORMATION_MESSAGE);
                }
                else{
                    finalistas.add(segundo);
                    JOptionPane.showMessageDialog(null,
                            (segundo.getNome()) , "Vencedor",
                            JOptionPane.INFORMATION_MESSAGE);
                }
                // caso a ponutação fornecida seja invalida
            } catch (PontuacaoInvalidaException e) {
                e.printStackTrace();
                throw new PontuacaoInvalidaException();
            }

        }

        for(int i=0; i < 4; i++){
            // faz as partidas finais
            Time primeiro = finalistas.get(0);
            Time segundo = finalistas.get(1);
            if(i%2!=0){
                primeiro = finalistas.get(1);
                segundo = finalistas.get(2);

            }

            try {
                // repete o procesos de obeter a pontuação do time
                int pontuacaoPrimeiro = getPontuacao(primeiro);
                int pontuacaoSegundo = getPontuacao(segundo);

                // muda a mensagem a ser exibida
                if(i==2){
                    JOptionPane.showMessageDialog(null,
                            ( primeiro.getNome() + " Vs " + segundo.getNome()) , "Final",
                            JOptionPane.INFORMATION_MESSAGE);
                }
                else{
                    JOptionPane.showMessageDialog(null,
                            ( primeiro.getNome() + " Vs " + segundo.getNome()) , "Semi-Final",
                            JOptionPane.INFORMATION_MESSAGE);
                }

                if(pontuacaoPrimeiro == pontuacaoSegundo) {
                    while(pontuacaoPrimeiro == pontuacaoSegundo) {
                        pontuacaoPrimeiro = getPontuacao(primeiro);
                        pontuacaoSegundo = getPontuacao(segundo);
                    }
                }

                // organiza a lista
                if(i==3){
                    // coloca o times perdedores no final da lista
                    if(pontuacaoPrimeiro > pontuacaoSegundo){
                        finalistas.remove(primeiro);
                        finalistas.add(primeiro);
                        finalistas.remove(segundo);
                        finalistas.add(segundo);
                        JOptionPane.showMessageDialog(null,
                                ( primeiro.getNome() ) , "Vencedor",
                                JOptionPane.INFORMATION_MESSAGE);
                    }
                    else{
                        finalistas.remove(segundo);
                        finalistas.add(segundo);
                        finalistas.remove(primeiro);
                        finalistas.add(primeiro);
                        JOptionPane.showMessageDialog(null,
                                ( segundo.getNome() ) , "Vencedor",
                                JOptionPane.INFORMATION_MESSAGE);
                    }
                }else{
                    // coloca os 3° e 4° lugares no final da lista
                    if(pontuacaoPrimeiro > pontuacaoSegundo){
                        finalistas.remove(segundo);
                        finalistas.add(segundo);
                        JOptionPane.showMessageDialog(null,
                                ( primeiro.getNome() ) , "Vencedor",
                                JOptionPane.INFORMATION_MESSAGE);
                    }
                    else{
                        finalistas.remove(primeiro);
                        finalistas.add(primeiro);
                        JOptionPane.showMessageDialog(null,
                                ( segundo.getNome() ) , "Vencedor",
                                JOptionPane.INFORMATION_MESSAGE);
                    }
                }

                // caso a ponutação fornecida seja invalida
            } catch (PontuacaoInvalidaException e) {
                e.printStackTrace();
                throw new PontuacaoInvalidaException();
            }
        }


        // cria um Arquivo.txt com as informações do time vencedor
        File file = new File("Arquivo.txt");
        try {
            FileWriter fw = new FileWriter(file);
            BufferedWriter bw = new BufferedWriter(fw);  //classe otimizada de escrita

            bw.write("Informações do time campeão");
            bw.newLine();
            String stringCampeao = finalistas.get(0).apresentar();
            bw.write(stringCampeao);
            bw.flush();
            bw.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        new TabelaVencedores(finalistas);
    }

    /**
     * função para pegar a pontuação fornecida pelo usuário e transformalo em int
     * @param time time a qual a pontuação vai ser atribuida
     * @return pontuação
     * @throws PontuacaoInvalidaException Caso a pontuação fornecida seja um valor invalido
     */
    private int getPontuacao(Time time) throws PontuacaoInvalidaException {
        String valor = JOptionPane.showInputDialog("Digite a pontuação do time " + time.getNome() + ":" );
        int pontuacao;
        if(validarNumero(valor)){
            pontuacao = Integer.parseInt(valor);
        }
        else{
            throw new PontuacaoInvalidaException();
        }
        return pontuacao;
    }

    /**
     * valida o numero fornecido
     * @param num numero fornecido
     * @return se é valido(true) ou não(false)
     */

    private boolean validarNumero(String num){
        if(num.matches("[0-9]+")){
            return true;
        }
        return false;
    }
}
