package TrabalhoFinalPOO.Gui;

import TrabalhoFinalPOO.Gui.TabelaTime;
import TrabalhoFinalPOO.Gui.TabelaVencedores;
import TrabalhoFinalPOO.ClasseBasicas.Jogador;
import TrabalhoFinalPOO.ClasseBasicas.TimesPreExistentes;
import TrabalhoFinalPOO.Collection.*;
import TrabalhoFinalPOO.Excecoes.*;
import TrabalhoFinalPOO.Collection.Time;
import TrabalhoFinalPOO.Excecoes.TimeVazioException;
import TrabalhoFinalPOO.Fachada.Fachada;

import java.awt.*;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/**
 * GUI principal do Torneio de Arco e Flecha.
 * Possui 4 abas, Cadastrar Jogador, Cadastrar Time, Campeonato e Times Pre Existentes.
 *
 * Em Cadastrar Jogador observa-se 5 regiões para inserir as informações do jogador e
 * 3 botões, Consultar, Adicionar e Excluir.
 * Consultar pede o ID do jogador e então preenche os campos de informações conforme o ID
 * inserido. Adicionar adiciona o jogadorno time selecionado caso ainda tenha espaço e limpa
 * as informações nos campos preenchidos. Excluir remove o jogador do time dele conforme o
 * ID inserido.
 *
 * Em Cadastrar Time observa-se um campo de texto para inserir o nome do time a ser adicionado
 * e 3 botões, Consultar, Adicionar e Excluir. Consultar pede o nome do time e chama TabelaTime.java
 * com as informações do time. Adicionar cria um novo time com o nome na caixa de texto. Excluir
 * recebe o nome do time e o remove.
 *
 * Em Campeonato observa-se 2 botões, Torneio Automático e Torneio Manual, ambos só funcionam com 8 times.
 * Torneio Automático inicia o torneio e mostra a partida em andamento e depois o vencedor, até o final
 * das chaves. Torneio Manual inicia o torneio e mostra a partida em andamento, pede para inserir a pontuação
 * dos times competindo e depois o vencedor, até o final das chaves.
 *
 * Em Times Pre Existentes observa-se 8 times com botões dos lados "Informações" que chamam TabelaTime.java
 * e mostram os jogadores do time para inserir no torneio ao selecionare adicionar por meio do botão Adicionar.
 * @author Amauri
 */

public class GuiArcoEFlecha {

    private JFrame frmCampeonatoDeArco;
    private Fachada fachada = Fachada.getInstance();

    /**
     * chama a aplicacao.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    GuiArcoEFlecha window = new GuiArcoEFlecha();
                    window.frmCampeonatoDeArco.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Cria a aplicacao
     */
    public GuiArcoEFlecha() {
        initialize();
    }

    /**
     * Inicializa o frame
     */

    private void initialize() {
        // cria o Jframe
        frmCampeonatoDeArco = new JFrame();
        frmCampeonatoDeArco.setResizable(false);
        frmCampeonatoDeArco.setTitle("Campeonato de Arco e Flecha");
        frmCampeonatoDeArco.setBounds(200, 200, 500, 300);
        frmCampeonatoDeArco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmCampeonatoDeArco.getContentPane().setLayout(new BorderLayout(0, 0));

        // cria o JTabbedPane
        JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
        frmCampeonatoDeArco.getContentPane().add(tabbedPane, BorderLayout.CENTER);

        // cria o Panel para exibir a interface de cadastro de um jogador
        JPanel Cadastrar_Jogador = new JPanel();
        Cadastrar_Jogador.setBackground(new Color(245, 245, 220));
        tabbedPane.addTab("Cadastrar Jogador", null, Cadastrar_Jogador, null);
        GridBagLayout gbl_Cadastrar_Jogador = new GridBagLayout();
        gbl_Cadastrar_Jogador.columnWidths = new int[]{30, 30, 63, 70, 133, 133, 30, 30, 30, 59};
        gbl_Cadastrar_Jogador.rowHeights = new int[]{30, 30, 30, 30, 30, 30, 30, 30, 30, 30};
        gbl_Cadastrar_Jogador.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0};
        gbl_Cadastrar_Jogador.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
        Cadastrar_Jogador.setLayout(gbl_Cadastrar_Jogador);

        // Jlabel com a informação nome
        JLabel nomeLabel = new JLabel("Nome:");
        GridBagConstraints gbc_nomeLabel = new GridBagConstraints();
        gbc_nomeLabel.fill = GridBagConstraints.HORIZONTAL;
        gbc_nomeLabel.insets = new Insets(0, 0, 5, 5);
        gbc_nomeLabel.gridx = 2;
        gbc_nomeLabel.gridy = 1;
        Cadastrar_Jogador.add(nomeLabel, gbc_nomeLabel);

        // JTextfiel que vai pegar o nome do jogador
        JTextField nome = new JTextField();
        nome.setBackground(new Color(255, 250, 240));
        nome.setHorizontalAlignment(SwingConstants.CENTER);
        GridBagConstraints gbc_nome = new GridBagConstraints();
        gbc_nome.fill = GridBagConstraints.HORIZONTAL;
        gbc_nome.gridwidth = 3;
        gbc_nome.insets = new Insets(0, 0, 5, 5);
        gbc_nome.gridx = 3;
        gbc_nome.gridy = 1;
        Cadastrar_Jogador.add(nome, gbc_nome);
        nome.setColumns(30);

        // Jlabel com a informação id
        JLabel idLabel = new JLabel("ID:");
        GridBagConstraints gbc_idLabel = new GridBagConstraints();
        gbc_idLabel.fill = GridBagConstraints.HORIZONTAL;
        gbc_idLabel.insets = new Insets(0, 0, 5, 5);
        gbc_idLabel.gridx = 2;
        gbc_idLabel.gridy = 2;
        Cadastrar_Jogador.add(idLabel, gbc_idLabel);

        // JTextField vai pegar o id do jogador
        JTextField id = new JTextField();
        id.setBackground(new Color(255, 250, 240));
        id.setHorizontalAlignment(SwingConstants.CENTER);
        id.setColumns(30);
        GridBagConstraints gbc_id = new GridBagConstraints();
        gbc_id.fill = GridBagConstraints.HORIZONTAL;
        gbc_id.insets = new Insets(0, 0, 5, 5);
        gbc_id.gridx = 3;
        gbc_id.gridy = 2;
        Cadastrar_Jogador.add(id, gbc_id);

        // para impedir que letras sejam digitadas no JTextField
        id.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (((c < '0') || (c > '9')) && (c != KeyEvent.VK_BACK_SPACE) ) {
                    e.consume();
                }
            }
        });

        // JLabel escrito precisao
        JLabel precisaoLabel = new JLabel("Precisao:");
        GridBagConstraints gbc_precisaoLabel = new GridBagConstraints();
        gbc_precisaoLabel.fill = GridBagConstraints.HORIZONTAL;
        gbc_precisaoLabel.insets = new Insets(0, 0, 5, 5);
        gbc_precisaoLabel.gridx = 2;
        gbc_precisaoLabel.gridy = 3;
        Cadastrar_Jogador.add(precisaoLabel, gbc_precisaoLabel);

        // JTextField vai pegar a precisao do jogador
        JTextField precisao = new JTextField();
        precisao.setBackground(new Color(255, 250, 240));
        precisao.setHorizontalAlignment(SwingConstants.CENTER);
        GridBagConstraints gbc_precisao = new GridBagConstraints();
        gbc_precisao.fill = GridBagConstraints.HORIZONTAL;
        gbc_precisao.insets = new Insets(0, 0, 5, 5);
        gbc_precisao.gridx = 3;
        gbc_precisao.gridy = 3;
        Cadastrar_Jogador.add(precisao, gbc_precisao);
        precisao.setColumns(50);

        // impede que digitos não numéricos sejam colocados no JTextField
        precisao.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (((c < '0') || (c > '9')) && (c != KeyEvent.VK_BACK_SPACE) && (c != '.')) {
                    e.consume();
                }
            }
        });

        // JLabel escrito Time
        JLabel TimeLabel = new JLabel("Time:");
        GridBagConstraints gbc_TimeLabel = new GridBagConstraints();
        gbc_TimeLabel.fill = GridBagConstraints.HORIZONTAL;
        gbc_TimeLabel.insets = new Insets(0, 0, 5, 5);
        gbc_TimeLabel.gridx = 2;
        gbc_TimeLabel.gridy = 4;
        Cadastrar_Jogador.add(TimeLabel, gbc_TimeLabel);

        // combo box que vai guardar o nome dos times que estão no torneio
        JComboBox comboBoxTimes = new JComboBox();
        comboBoxTimes.setBackground(new Color(255, 250, 240));
        GridBagConstraints gbc_comboBoxTimes = new GridBagConstraints();
        gbc_comboBoxTimes.gridwidth = 2;
        gbc_comboBoxTimes.fill = GridBagConstraints.HORIZONTAL;
        gbc_comboBoxTimes.insets = new Insets(0, 0, 5, 5);
        gbc_comboBoxTimes.gridx = 3;
        gbc_comboBoxTimes.gridy = 4;
        Cadastrar_Jogador.add(comboBoxTimes, gbc_comboBoxTimes);

        // JTextField vai pegar a precisao do jogador
        JLabel lesionadoLabel = new JLabel("Lesionado:");
        GridBagConstraints gbc_lesionadoLabel = new GridBagConstraints();
        gbc_lesionadoLabel.fill = GridBagConstraints.HORIZONTAL;
        gbc_lesionadoLabel.insets = new Insets(0, 0, 5, 5);
        gbc_lesionadoLabel.gridx = 2;
        gbc_lesionadoLabel.gridy = 5;
        Cadastrar_Jogador.add(lesionadoLabel, gbc_lesionadoLabel);

        // JCheckBox que vai ser usada para definir se um jogador está lesionado ou não
        JCheckBox lesionadoCheck = new JCheckBox("Sim");
        lesionadoCheck.setBackground(new Color(245, 245, 220));
        GridBagConstraints gbc_lesionadoCheck = new GridBagConstraints();
        gbc_lesionadoCheck.insets = new Insets(0, 0, 5, 5);
        gbc_lesionadoCheck.gridx = 3;
        gbc_lesionadoCheck.gridy = 5;
        Cadastrar_Jogador.add(lesionadoCheck, gbc_lesionadoCheck);

        JCheckBox noLesionadoCheck = new JCheckBox("Não");
        noLesionadoCheck.setBackground(new Color(245, 245, 220));
        GridBagConstraints gbc_noLesionadoCheck = new GridBagConstraints();
        gbc_noLesionadoCheck.anchor = GridBagConstraints.WEST;
        gbc_noLesionadoCheck.insets = new Insets(0, 0, 5, 5);
        gbc_noLesionadoCheck.gridx = 4;
        gbc_noLesionadoCheck.gridy = 5;
        Cadastrar_Jogador.add(noLesionadoCheck, gbc_noLesionadoCheck);

        // caso uma das JCheckBox esteja selecionada a outra é automaticamente desmarcada
        lesionadoCheck.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(lesionadoCheck.isSelected()){
                    noLesionadoCheck.setSelected(false);
                }
            }
        });

        noLesionadoCheck.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(noLesionadoCheck.isSelected()){
                    lesionadoCheck.setSelected(false);
                }
            }
        });

        // botão para consultar um jogador pelo seu ID
        JButton consultarJogador = new JButton("Consultar");
        consultarJogador.setBackground(new Color(255, 255, 224));

        GridBagConstraints gbc_consultarJogador = new GridBagConstraints();
        gbc_consultarJogador.gridwidth = 2;
        gbc_consultarJogador.fill = GridBagConstraints.HORIZONTAL;
        gbc_consultarJogador.insets = new Insets(0, 0, 5, 5);
        gbc_consultarJogador.gridx = 2;
        gbc_consultarJogador.gridy = 7;
        Cadastrar_Jogador.add(consultarJogador, gbc_consultarJogador);

        // verifica as informações fornecidas pelo usuário e apresenta na área de cadastro do jogador, as informações
        // do jogador procurado
        consultarJogador.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                //recebe o id
                String buscar = JOptionPane.showInputDialog("Digite o ID do candidato:");
                try {
                    // caso seja valido, ele apresenta as informações
                    //        // do jogador procurado
                    Jogador procurado = fachada.consultarJogador(Integer.parseInt(buscar));
                    nome.setText(procurado.getNome());
                    id.setText(String.valueOf(procurado.getId()));
                    precisao.setText(String.valueOf(procurado.getPrecisao()));
                    comboBoxTimes.setSelectedItem(fachada.jogadorPertenceTime(procurado.getId()).getNome());
                    if(procurado.isLesionado()) {
                        lesionadoCheck.setSelected(true);
                        noLesionadoCheck.setSelected(false);
                    }
                    else{
                        noLesionadoCheck.setSelected(true);
                        lesionadoCheck.setSelected(false);
                    };

                    // caso o jogador não seja encontrado
                } catch (TrabalhoFinalPOO.Excecoes.JogadorInexistenteException ex) {
                    JOptionPane.showMessageDialog(null,
                            "Jogador Inexistente!", "Mensagem",
                            JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        // botão para adicionar um jogador
        JButton adicionarJogador = new JButton("Adicionar");
        adicionarJogador.setBackground(new Color(255, 255, 224));

        GridBagConstraints gbc_adicionarJogador = new GridBagConstraints();
        gbc_adicionarJogador.fill = GridBagConstraints.HORIZONTAL;
        gbc_adicionarJogador.insets = new Insets(0, 0, 5, 5);
        gbc_adicionarJogador.gridx = 4;
        gbc_adicionarJogador.gridy = 7;
        Cadastrar_Jogador.add(adicionarJogador, gbc_adicionarJogador);

        // valida as informações de um jogador e adiciona ele
        adicionarJogador.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // verifica se algum dos campos de informações está vazio
                if (precisao.getText().isEmpty() || nome.getText().isEmpty() || comboBoxTimes.getSelectedItem() == null ||
                        id.getText().isEmpty() || (!noLesionadoCheck.isSelected() && !lesionadoCheck.isSelected())) {
                    JOptionPane.showMessageDialog(null,
                            "Preencha todos os campo!", "Mensagem",
                            JOptionPane.INFORMATION_MESSAGE);
                } else {
                    // tenta adicionar o jogador
                    try {
                        //caso o jogador já exista, retorna esse erro
                        fachada.consultarJogador(Integer.parseInt(id.getText()));
                        JOptionPane.showMessageDialog(null,
                                "Jogador já existente!", "Mensagem",
                                JOptionPane.INFORMATION_MESSAGE);
                    } catch (TrabalhoFinalPOO.Excecoes.JogadorInexistenteException ex) {
                        // se ele não existir
                        double valorPrescisao = Double.parseDouble(precisao.getText());
                        // verifica se a prescisão é um número real valido
                        if (valorPrescisao < 1) {
                            // cria um jogador e tenta adicionar ele ao time
                            Jogador novo = new Jogador(nome.getText(), Integer.parseInt(id.getText()),
                                    valorPrescisao, lesionadoCheck.isSelected());
                            String nomeTime = (String) comboBoxTimes.getSelectedItem();
                            try {
                                Time time = fachada.consultarTime(nomeTime);
                                fachada.cadastrarJogador(nomeTime, novo);
                                JOptionPane.showMessageDialog(null,
                                        "Jogador adicionado!", "Mensagem",
                                        JOptionPane.INFORMATION_MESSAGE);
                            } catch (TimeInexistenteException exc) {
                                JOptionPane.showMessageDialog(null,
                                        "Time Inexistente", "Mensagem",
                                        JOptionPane.INFORMATION_MESSAGE);
                            } catch (TrabalhoFinalPOO.Excecoes.TimeCompletoException exc) {
                                JOptionPane.showMessageDialog(null,
                                        "Time Completo!", "Mensagem",
                                        JOptionPane.INFORMATION_MESSAGE);
                            }
                            // limpa as informações do cadastro
                            nome.setText("");
                            id.setText("");
                            precisao.setText("");
                            comboBoxTimes.setSelectedItem(0);
                            lesionadoCheck.setSelected(false);
                            noLesionadoCheck.setSelected(false);
                        }
                        else{
                            // caso a prescião seja um valor inválido
                            JOptionPane.showMessageDialog(null,
                                    "A precisão é um número real que vai de 0 a 1", "Mensagem",
                                    JOptionPane.INFORMATION_MESSAGE);
                        }
                    }
                }
            }
        });

        // botão para excluir um jogador
        JButton excluirJogador = new JButton("Excluir");
        excluirJogador.setBackground(new Color(255, 255, 224));

        GridBagConstraints gbc_excluir = new GridBagConstraints();
        gbc_excluir.fill = GridBagConstraints.HORIZONTAL;
        gbc_excluir.insets = new Insets(0, 0, 5, 5);
        gbc_excluir.gridx = 5;
        gbc_excluir.gridy = 7;
        Cadastrar_Jogador.add(excluirJogador, gbc_excluir);

        // recebe o Id do jogador e tenta excluir
        excluirJogador.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String buscar = JOptionPane.showInputDialog("Digite o ID do candidato:");
                try {
                    fachada.excluirJogador(Integer.parseInt(buscar));
                    JOptionPane.showMessageDialog(null,
                            "Jogador exlcluido!", "Mensagem",
                            JOptionPane.INFORMATION_MESSAGE);
                } catch (TrabalhoFinalPOO.Excecoes.JogadorInexistenteException ex) {
                    JOptionPane.showMessageDialog(null,
                            "Jogador Inexistente", "Mensagem",
                            JOptionPane.INFORMATION_MESSAGE);
                }

            }
        });

        // cria o Panel de cadastro de times
        JPanel Cadastrar_Time = new JPanel();
        Cadastrar_Time.setBackground(new Color(245, 245, 220));
        tabbedPane.addTab("Cadastrar Time", null, Cadastrar_Time, null);
        GridBagLayout gbl_Cadastrar_Time = new GridBagLayout();
        gbl_Cadastrar_Time.columnWidths = new int[]{33, 33, 33, 133, 133, 133, 33, 33, 33, 0};
        gbl_Cadastrar_Time.rowHeights = new int[]{20, 30, 30, 30, 30, 30};
        gbl_Cadastrar_Time.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
        gbl_Cadastrar_Time.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
        Cadastrar_Time.setLayout(gbl_Cadastrar_Time);

        // cria o Label escrito "nome do time"
        JLabel nomeTimeLabal = new JLabel("Nome do Time:");
        nomeTimeLabal.setHorizontalAlignment(SwingConstants.CENTER);
        GridBagConstraints gbc_nomeTimeLabal = new GridBagConstraints();
        gbc_nomeTimeLabal.fill = GridBagConstraints.HORIZONTAL;
        gbc_nomeTimeLabal.insets = new Insets(0, 0, 5, 5);
        gbc_nomeTimeLabal.gridx = 3;
        gbc_nomeTimeLabal.gridy = 1;
        Cadastrar_Time.add(nomeTimeLabal, gbc_nomeTimeLabal);

        // cria o JTextFieldque guarda o nome do time
        JTextField NomeTime = new JTextField();
        NomeTime.setBackground(new Color(255, 250, 240));
        NomeTime.setHorizontalAlignment(SwingConstants.CENTER);
        GridBagConstraints gbc_NomeTime = new GridBagConstraints();
        gbc_NomeTime.gridwidth = 2;
        gbc_NomeTime.fill = GridBagConstraints.HORIZONTAL;
        gbc_NomeTime.insets = new Insets(0, 0, 5, 0);
        gbc_NomeTime.gridx = 4;
        gbc_NomeTime.gridy = 1;
        Cadastrar_Time.add(NomeTime, gbc_NomeTime);
        NomeTime.setColumns(10);

        // botão para consultar o time
        JButton consultarTime = new JButton("Consultar");
        consultarTime.setBackground(new Color(255, 255, 224));
        GridBagConstraints gbc_consultarTime = new GridBagConstraints();
        gbc_consultarTime.fill = GridBagConstraints.HORIZONTAL;
        gbc_consultarTime.insets = new Insets(0, 0, 5, 5);
        gbc_consultarTime.gridx = 3;
        gbc_consultarTime.gridy = 4;
        Cadastrar_Time.add(consultarTime, gbc_consultarTime);

        // recebe o nome do time e tenta encontra-lo
        consultarTime.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //recebe o nome do time
                String buscar = JOptionPane.showInputDialog("Digite o nome do Time:");
                try {
                    // acha o time e exibe ele em uma tabela
                    Time time = fachada.consultarTime(buscar);
                    new TabelaTime(time);
                } catch (TimeInexistenteException ex) {
                    JOptionPane.showMessageDialog(null,
                            "Time Inexistente", "Mensagem",
                            JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        // botão para adicionar um time
        JButton adicionarTime = new JButton("Adicionar");
        adicionarTime.setBackground(new Color(255, 255, 224));

        GridBagConstraints gbc_adicionarTime = new GridBagConstraints();
        gbc_adicionarTime.fill = GridBagConstraints.HORIZONTAL;
        gbc_adicionarTime.insets = new Insets(0, 0, 5, 5);
        gbc_adicionarTime.gridx = 4;
        gbc_adicionarTime.gridy = 4;
        Cadastrar_Time.add(adicionarTime, gbc_adicionarTime);

        // tenta adicionar um time ao torneio
        adicionarTime.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // caso a String passada esteja vazia
                if (NomeTime.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(null,
                            "Adicione o nome do time", "Mensagem",
                            JOptionPane.INFORMATION_MESSAGE);
                    // caso o número máximo de times já esteja cadastrados
                } else if (fachada.totalTimes() >= 8) {
                    JOptionPane.showMessageDialog(null,
                            "Número máximo de times cadastrados!", "Mensagem",
                            JOptionPane.INFORMATION_MESSAGE);
                } else {
                    // tenta cadastrar o time
                    Time novo = new Time(NomeTime.getText());
                    try {
                        fachada.adicionarTime(novo);
                        comboBoxTimes.addItem(NomeTime.getText());
                        JOptionPane.showMessageDialog(null,
                                "Time adicionado!", "Mensagem",
                                JOptionPane.INFORMATION_MESSAGE);
                    } catch (TimeJaExistenteException ex) {
                        JOptionPane.showMessageDialog(null,
                                "Time já existente!", "Mensagem",
                                JOptionPane.INFORMATION_MESSAGE);
                    }
                    NomeTime.setText("");
                }
            }
        });

        // botão para excluir time
        JButton excluirTime = new JButton("Excluir");
        excluirTime.setBackground(new Color(255, 255, 224));

        GridBagConstraints gbc_excluirTime = new GridBagConstraints();
        gbc_excluirTime.insets = new Insets(0, 0, 5, 0);
        gbc_excluirTime.fill = GridBagConstraints.HORIZONTAL;
        gbc_excluirTime.gridx = 5;
        gbc_excluirTime.gridy = 4;
        Cadastrar_Time.add(excluirTime, gbc_excluirTime);

        // tenta excluir um time do torneio
        excluirTime.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // recebe o nome do time
                String buscar = JOptionPane.showInputDialog("Digite o nome do Time:");
                try {
                    //exclui um time
                    fachada.excluirTime(buscar);
                    comboBoxTimes.removeItem(buscar);
                    JOptionPane.showMessageDialog(null,
                            "Time excluido!", "Mensagem",
                            JOptionPane.INFORMATION_MESSAGE);
                } catch (TrabalhoFinalPOO.Excecoes.TimeInexistenteException ex) {
                    // caso o time não seja encontrado
                    if (!buscar.isEmpty()) {
                        JOptionPane.showMessageDialog(null,
                                "Time Inexistente", "Mensagem",
                                JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
        });

        // cria o Panel com os botões para iniciar o campeonato
        JPanel Campeonato = new JPanel();
        Campeonato.setBackground(new Color(245, 245, 220));
        tabbedPane.addTab("Campeonato", null, Campeonato, null);
        GridBagLayout gbl_Campeonato = new GridBagLayout();
        gbl_Campeonato.columnWidths = new int[] {55, 160, 30, 160, 65};
        gbl_Campeonato.rowHeights = new int[]{20, 30, 30};
        gbl_Campeonato.columnWeights = new double[]{0.0, 1.0, 0.0, 1.0};
        gbl_Campeonato.rowWeights = new double[]{0.0, 0.0, 0.0};
        Campeonato.setLayout(gbl_Campeonato);

        // botão para iniciar o torneio automatico
        JButton comecarTorneioAutoMatico = new JButton("Torneio Automático");
        comecarTorneioAutoMatico.setBackground(new Color(255, 255, 224));
        GridBagConstraints gbc_comecarTorneioAutoMatico = new GridBagConstraints();
        gbc_comecarTorneioAutoMatico.fill = GridBagConstraints.BOTH;
        gbc_comecarTorneioAutoMatico.gridheight = 3;
        gbc_comecarTorneioAutoMatico.insets = new Insets(0, 0, 0, 5);
        gbc_comecarTorneioAutoMatico.gridx = 1;
        gbc_comecarTorneioAutoMatico.gridy = 0;
        Campeonato.add(comecarTorneioAutoMatico, gbc_comecarTorneioAutoMatico);

        // comeca o torneio automatico
        comecarTorneioAutoMatico.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // se o número de times for igual a 8 o o tornei começa
                if (fachada.getTimes().size() == 8) {
                    try {
                        // chama a gui tabela vencedores para exibir os 4 melhores times e a fachada para comecar
                        // campeonato
                        new TabelaVencedores(fachada.comecarTorneioAutoMatico());
                    } catch (TrabalhoFinalPOO.Excecoes.TimeIncompletoException ex) {
                        // caso algum time esteja incompleto
                        JOptionPane.showMessageDialog(null,
                                "Um time está incompleto", "Mensagem",
                                JOptionPane.INFORMATION_MESSAGE);
                    } catch (TimeVazioException ex) {
                        // caso algum time esteja vazio
                        JOptionPane.showMessageDialog(null,
                                "Um time está vazio", "Mensagem",
                                JOptionPane.INFORMATION_MESSAGE);
                    }
                } else {
                    // caso tenha menos de 8 times
                    JOptionPane.showMessageDialog(null,
                            "É necessário cadastrar 8 times para o jogo começar!!!", "Mensagem",
                            JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        // botão para comecar o torneio manual
        JButton comecarTorneioManual = new JButton("Torneio Manual");
        comecarTorneioManual.setBackground(new Color(255, 255, 224));
        GridBagConstraints gbc_comecarTorneioManual = new GridBagConstraints();
        gbc_comecarTorneioManual.fill = GridBagConstraints.BOTH;
        gbc_comecarTorneioManual.gridheight = 3;
        gbc_comecarTorneioManual.gridx = 3;
        gbc_comecarTorneioManual.gridy = 0;
        Campeonato.add(comecarTorneioManual, gbc_comecarTorneioManual);

        //comeca o torneio que é definido a mão a pontuação
        comecarTorneioManual.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // se o número de times for igual a 8 o o tornei começa
                if (fachada.getTimes().size() == 8) {
                    try {
                        // chama a fachada para comecar campeonato
                        fachada.comecarTorneioManual();
                    } catch (TrabalhoFinalPOO.Excecoes.TimeIncompletoException ex) {
                        // caso algum time esteja incompleto
                        JOptionPane.showMessageDialog(null,
                                "Um time está incompleto", "Mensagem",
                                JOptionPane.INFORMATION_MESSAGE);
                    } catch (TimeVazioException ex) {
                        // caso algum time esteja vazio
                        JOptionPane.showMessageDialog(null,
                                "Um time está vazio", "Mensagem",
                                JOptionPane.INFORMATION_MESSAGE);
                    } catch (PontuacaoInvalidaException ex) {
                        // caso a pontuação fornecida não seja composta apenas de números
                        JOptionPane.showMessageDialog(null,
                                "Por favor, não use letras na pontuação!!", "Mensagem",
                                JOptionPane.INFORMATION_MESSAGE);
                    }
                } else {
                    // caso tenha menos de 8 times
                    JOptionPane.showMessageDialog(null,
                            "É necessário cadastrar 8 times para o jogo começar!!!", "Mensagem",
                            JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        // cria um panel para exibir os time pre existentes
        JPanel Times_Pre_Existentes = new JPanel();
        tabbedPane.addTab("Times Pre Existentes", null, Times_Pre_Existentes, null);
        Times_Pre_Existentes.setLayout(new BorderLayout(0, 0));

        // cria um JPanel informações para que recebe o JLabel lbTimesExistentesl
        JPanel panelInformacoes = new JPanel();
        panelInformacoes.setBackground(new Color(245, 245, 220));
        Times_Pre_Existentes.add(panelInformacoes, BorderLayout.NORTH);
        panelInformacoes.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));

        // cria um JLabel
        JLabel lbTimesExistentesl = new JLabel("Clique em marcar para adicionar os times existentes ao torneio");
        panelInformacoes.add(lbTimesExistentesl);

        // cria um Panel para exibir os times pre existentes
        JPanel timesPreExistentesPanel = new JPanel();
        timesPreExistentesPanel.setBackground(new Color(245, 245, 220));
        Times_Pre_Existentes.add(timesPreExistentesPanel, BorderLayout.CENTER);
        GridBagLayout gbl_timesPreExistentesPanel = new GridBagLayout();
        gbl_timesPreExistentesPanel.columnWidths = new int[]{100, 100, 100, 100, 100, 100};
        gbl_timesPreExistentesPanel.rowHeights = new int[]{30, 20, 20, 10, 10, 30, 0, 30};
        gbl_timesPreExistentesPanel.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
        gbl_timesPreExistentesPanel.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
        timesPreExistentesPanel.setLayout(gbl_timesPreExistentesPanel);

        // cria um JRadioButton para macar o timeAzul
        JRadioButton timeAzul = new JRadioButton("Time Azul");
        timeAzul.setBackground(new Color(245, 245, 220));
        GridBagConstraints gbc_timeAzul = new GridBagConstraints();
        gbc_timeAzul.fill = GridBagConstraints.VERTICAL;
        gbc_timeAzul.anchor = GridBagConstraints.WEST;
        gbc_timeAzul.insets = new Insets(0, 0, 5, 5);
        gbc_timeAzul.gridx = 1;
        gbc_timeAzul.gridy = 1;
        timesPreExistentesPanel.add(timeAzul, gbc_timeAzul);

        // cria um botão com as informações do timeAzul
        JButton informacoesAzul = new JButton("Informações");
        informacoesAzul.setBackground(new Color(255, 250, 205));
        GridBagConstraints gbc_informacoesAzul = new GridBagConstraints();
        gbc_informacoesAzul.fill = GridBagConstraints.VERTICAL;
        gbc_informacoesAzul.insets = new Insets(0, 0, 5, 5);
        gbc_informacoesAzul.gridx = 2;
        gbc_informacoesAzul.gridy = 1;
        timesPreExistentesPanel.add(informacoesAzul, gbc_informacoesAzul);

        // cria um JRadioButton para macar o timeReal
        JRadioButton timeReal = new JRadioButton("Time Real");
        timeReal.setBackground(new Color(245, 245, 220));
        GridBagConstraints gbc_timeReal = new GridBagConstraints();
        gbc_timeReal.fill = GridBagConstraints.VERTICAL;
        gbc_timeReal.anchor = GridBagConstraints.WEST;
        gbc_timeReal.insets = new Insets(0, 0, 5, 5);
        gbc_timeReal.gridx = 3;
        gbc_timeReal.gridy = 1;
        timesPreExistentesPanel.add(timeReal, gbc_timeReal);

        // cria um botão com as informações do timeReal
        JButton informacoesReal = new JButton("Informações");
        informacoesReal.setBackground(new Color(255, 250, 205));
        GridBagConstraints gbc_informacoesReal = new GridBagConstraints();
        gbc_informacoesReal.fill = GridBagConstraints.VERTICAL;
        gbc_informacoesReal.insets = new Insets(0, 0, 5, 5);
        gbc_informacoesReal.gridx = 4;
        gbc_informacoesReal.gridy = 1;
        timesPreExistentesPanel.add(informacoesReal, gbc_informacoesReal);

        // cria um JRadioButton para macar o timeAmarelo
        JRadioButton timeAmarelo = new JRadioButton("Time Amarelo");
        timeAmarelo.setBackground(new Color(245, 245, 220));
        GridBagConstraints gbc_timeAmarelo = new GridBagConstraints();
        gbc_timeAmarelo.anchor = GridBagConstraints.WEST;
        gbc_timeAmarelo.insets = new Insets(0, 0, 5, 5);
        gbc_timeAmarelo.gridx = 1;
        gbc_timeAmarelo.gridy = 2;
        timesPreExistentesPanel.add(timeAmarelo, gbc_timeAmarelo);

        // cria um botão com as informações do timeAmarelo
        JButton informacoesAmarelo = new JButton("Informações");
        informacoesAmarelo.setBackground(new Color(255, 250, 205));
        GridBagConstraints gbc_informacoesAmarelo = new GridBagConstraints();
        gbc_informacoesAmarelo.insets = new Insets(0, 0, 5, 5);
        gbc_informacoesAmarelo.gridx = 2;
        gbc_informacoesAmarelo.gridy = 2;
        timesPreExistentesPanel.add(informacoesAmarelo, gbc_informacoesAmarelo);

        // cria um JRadioButton para macar o timeVermelho
        JRadioButton timeVermelho = new JRadioButton("Time Vermelho");
        timeVermelho.setBackground(new Color(245, 245, 220));
        GridBagConstraints gbc_timeVermelho = new GridBagConstraints();
        gbc_timeVermelho.anchor = GridBagConstraints.WEST;
        gbc_timeVermelho.insets = new Insets(0, 0, 5, 5);
        gbc_timeVermelho.gridx = 3;
        gbc_timeVermelho.gridy = 2;
        timesPreExistentesPanel.add(timeVermelho, gbc_timeVermelho);

        // cria um botão com as informações do timeVermelho
        JButton informacoesVermelho = new JButton("Informações");
        informacoesVermelho.setBackground(new Color(255, 250, 205));
        GridBagConstraints gbc_informacoesVermelho = new GridBagConstraints();
        gbc_informacoesVermelho.insets = new Insets(0, 0, 5, 5);
        gbc_informacoesVermelho.gridx = 4;
        gbc_informacoesVermelho.gridy = 2;
        timesPreExistentesPanel.add(informacoesVermelho, gbc_informacoesVermelho);

        // cria um JRadioButton para macar o timeCinza
        JRadioButton timeCinza = new JRadioButton("Time Cinza");
        timeCinza.setBackground(new Color(245, 245, 220));
        GridBagConstraints gbc_timeCinza = new GridBagConstraints();
        gbc_timeCinza.anchor = GridBagConstraints.WEST;
        gbc_timeCinza.insets = new Insets(0, 0, 5, 5);
        gbc_timeCinza.gridx = 1;
        gbc_timeCinza.gridy = 3;
        timesPreExistentesPanel.add(timeCinza, gbc_timeCinza);

        // cria um botão com as informações do timeCinza
        JButton informacoesCinza = new JButton("Informações");
        informacoesCinza.setBackground(new Color(255, 250, 205));
        GridBagConstraints gbc_informacoesCinza = new GridBagConstraints();
        gbc_informacoesCinza.insets = new Insets(0, 0, 5, 5);
        gbc_informacoesCinza.gridx = 2;
        gbc_informacoesCinza.gridy = 3;
        timesPreExistentesPanel.add(informacoesCinza, gbc_informacoesCinza);

        // cria um JRadioButton para macar o timeLaranja
        JRadioButton timeLaranja = new JRadioButton("Time Laranja");
        timeLaranja.setBackground(new Color(245, 245, 220));
        GridBagConstraints gbc_timeLaranja = new GridBagConstraints();
        gbc_timeLaranja.anchor = GridBagConstraints.WEST;
        gbc_timeLaranja.insets = new Insets(0, 0, 5, 5);
        gbc_timeLaranja.gridx = 3;
        gbc_timeLaranja.gridy = 3;
        timesPreExistentesPanel.add(timeLaranja, gbc_timeLaranja);

        // cria um botão com as informações do timeLaranja
        JButton informacoesLaranja = new JButton("Informações");
        informacoesLaranja.setBackground(new Color(255, 250, 205));
        GridBagConstraints gbc_informacoesLaranja = new GridBagConstraints();
        gbc_informacoesLaranja.insets = new Insets(0, 0, 5, 5);
        gbc_informacoesLaranja.gridx = 4;
        gbc_informacoesLaranja.gridy = 3;
        timesPreExistentesPanel.add(informacoesLaranja, gbc_informacoesLaranja);

        // cria um JRadioButton para macar o timeVasco
        JRadioButton timeVasco = new JRadioButton("Time Vasco");
        timeVasco.setBackground(new Color(245, 245, 220));
        GridBagConstraints gbc_timeVasco = new GridBagConstraints();
        gbc_timeVasco.anchor = GridBagConstraints.WEST;
        gbc_timeVasco.insets = new Insets(0, 0, 5, 5);
        gbc_timeVasco.gridx = 1;
        gbc_timeVasco.gridy = 4;
        timesPreExistentesPanel.add(timeVasco, gbc_timeVasco);

        // cria um botão com as informações do timeVasco
        JButton informacoesVasco = new JButton("Informações");
        informacoesVasco.setBackground(new Color(255, 250, 205));
        GridBagConstraints gbc_informacoesVasco = new GridBagConstraints();
        gbc_informacoesVasco.insets = new Insets(0, 0, 5, 5);
        gbc_informacoesVasco.gridx = 2;
        gbc_informacoesVasco.gridy = 4;
        timesPreExistentesPanel.add(informacoesVasco, gbc_informacoesVasco);

        // cria um JRadioButton para adicionar o timeVerde
        JRadioButton timeVerde = new JRadioButton("Time Verde");
        timeVerde.setBackground(new Color(245, 245, 220));
        GridBagConstraints gbc_timeVerde = new GridBagConstraints();
        gbc_timeVerde.anchor = GridBagConstraints.WEST;
        gbc_timeVerde.insets = new Insets(0, 0, 5, 5);
        gbc_timeVerde.gridx = 3;
        gbc_timeVerde.gridy = 4;
        timesPreExistentesPanel.add(timeVerde, gbc_timeVerde);

        // cria um botão com as informações do timeVerde
        JButton informacoesVerde = new JButton("Informações");
        informacoesVerde.setBackground(new Color(255, 250, 205));
        GridBagConstraints gbc_informacoesVerde = new GridBagConstraints();
        gbc_informacoesVerde.insets = new Insets(0, 0, 5, 5);
        gbc_informacoesVerde.gridx = 4;
        gbc_informacoesVerde.gridy = 4;
        timesPreExistentesPanel.add(informacoesVerde, gbc_informacoesVerde);

        // Cria um botão para adicionar os times pre existentes selecionados ao torneio
        JButton btnAdicionar = new JButton("Adicionar");
        btnAdicionar.setBackground(new Color(255, 255, 224));
        btnAdicionar.setVerticalAlignment(SwingConstants.BOTTOM);
        GridBagConstraints gbc_btnAdicionar = new GridBagConstraints();
        gbc_btnAdicionar.gridwidth = 2;
        gbc_btnAdicionar.fill = GridBagConstraints.HORIZONTAL;
        gbc_btnAdicionar.insets = new Insets(0, 0, 5, 5);
        gbc_btnAdicionar.gridx = 2;
        gbc_btnAdicionar.gridy = 6;
        timesPreExistentesPanel.add(btnAdicionar, gbc_btnAdicionar);

        // botões que se clicados cira uma tabela com as informações do time selecionado
        informacoesCinza.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new TabelaTime(TimesPreExistentes.getTimeCinza());
            }
        });

        informacoesAmarelo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new TabelaTime(TimesPreExistentes.getTimeAmarelo());
            }
        });

        informacoesLaranja.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new TabelaTime(TimesPreExistentes.getTimeLaranja());
            }
        });

        informacoesAzul.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new TabelaTime(TimesPreExistentes.getTimeAzul());
            }
        });

        informacoesVasco.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new TabelaTime(TimesPreExistentes.getTimeVasco());
            }
        });

        informacoesReal.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new TabelaTime(TimesPreExistentes.getTimeReal());
            }
        });

        informacoesVerde.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new TabelaTime(TimesPreExistentes.getTimeVerde());
            }
        });

        informacoesVermelho.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new TabelaTime(TimesPreExistentes.getTimeVermelho());
            }
        });

        // botão para adicionar os times pre-selecionados marcados ao torneio
        btnAdicionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // verifica tem vagas para os times e tenta adiciona-los ao torneio
                int num = fachada.totalTimes();
                if (timeAmarelo.isSelected()) {
                    if (num >= 8) {
                        JOptionPane.showMessageDialog(null,
                                "Número máximo de times cadastrados", "Mensagem",
                                JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        try {
                            fachada.adicionarTime(TimesPreExistentes.getTimeAmarelo());
                            comboBoxTimes.addItem("timeAmarelo");
                            num++;
                        } catch (TimeJaExistenteException ex) {
                            JOptionPane.showMessageDialog(null,
                                    "Time já adicionado", "Mensagem",
                                    JOptionPane.INFORMATION_MESSAGE);
                        }
                    }
                    timeAmarelo.setSelected(false);
                }
                if (timeCinza.isSelected()) {
                    if (num >= 8) {
                        JOptionPane.showMessageDialog(null,
                                "Número máximo de times cadastrados", "Mensagem",
                                JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        try {
                            fachada.adicionarTime(TimesPreExistentes.getTimeCinza());
                            comboBoxTimes.addItem("timeCinza");
                            num++;
                        } catch (TimeJaExistenteException ex) {
                            JOptionPane.showMessageDialog(null,
                                    "Time já adicionado", "Mensagem",
                                    JOptionPane.INFORMATION_MESSAGE);
                        }

                    }
                    timeCinza.setSelected(false);
                }
                if (timeLaranja.isSelected()) {
                    if (num >= 8) {
                        JOptionPane.showMessageDialog(null,
                                "Número máximo de times cadastrados", "Mensagem",
                                JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        try {
                            fachada.adicionarTime(TimesPreExistentes.getTimeLaranja());
                            comboBoxTimes.addItem("timeLaranja");
                            num++;
                        } catch (TimeJaExistenteException ex) {
                            JOptionPane.showMessageDialog(null,
                                    "Time já adicionado", "Mensagem",
                                    JOptionPane.INFORMATION_MESSAGE);
                        }

                    }
                    timeLaranja.setSelected(false);
                }
                if (timeAzul.isSelected()) {
                    if (num >= 8) {
                        JOptionPane.showMessageDialog(null,
                                "Número máximo de times cadastrados", "Mensagem",
                                JOptionPane.INFORMATION_MESSAGE);
                    } else{
                        try {
                            fachada.adicionarTime(TimesPreExistentes.getTimeAzul());
                            comboBoxTimes.addItem("timeAzul");
                            num++;
                        } catch (TimeJaExistenteException ex) {
                            JOptionPane.showMessageDialog(null,
                                    "Time já adicionado", "Mensagem",
                                    JOptionPane.INFORMATION_MESSAGE);
                        }

                    }
                    timeAzul.setSelected(false);
                }
                if (timeReal.isSelected()) {
                    if (num >= 8) {
                        JOptionPane.showMessageDialog(null,
                                "Número máximo de times cadastrados", "Mensagem",
                                JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        try {
                            fachada.adicionarTime(TimesPreExistentes.getTimeReal());
                            comboBoxTimes.addItem("timeReal");
                            num++;
                        } catch (TimeJaExistenteException ex) {
                            JOptionPane.showMessageDialog(null,
                                    "Time já adicionado", "Mensagem",
                                    JOptionPane.INFORMATION_MESSAGE);
                        }
                    }
                    timeReal.setSelected(false);
                }
                if (timeVasco.isSelected()) {
                    if (num >= 8) {
                        JOptionPane.showMessageDialog(null,
                                "Número máximo de times cadastrados", "Mensagem",
                                JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        try {
                            fachada.adicionarTime(TimesPreExistentes.getTimeVasco());
                            comboBoxTimes.addItem("timeVasco");
                            num++;
                        } catch (TimeJaExistenteException ex) {
                            JOptionPane.showMessageDialog(null,
                                    "Time já adicionado", "Mensagem",
                                    JOptionPane.INFORMATION_MESSAGE);
                        }
                    }
                    timeVasco.setSelected(false);
                }
                if (timeVerde.isSelected()) {
                    if (num >= 8) {
                        JOptionPane.showMessageDialog(null,
                                "Número máximo de times cadastrados", "Mensagem",
                                JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        try {
                            fachada.adicionarTime(TimesPreExistentes.getTimeVerde());
                            comboBoxTimes.addItem("timeVerde");
                            num++;
                        } catch (TimeJaExistenteException ex) {
                            JOptionPane.showMessageDialog(null,
                                    "Time já adicionado", "Mensagem",
                                    JOptionPane.INFORMATION_MESSAGE);
                        }
                    }
                    timeVerde.setSelected(false);
                }
                if (timeVermelho.isSelected()) {
                    if (num >= 8) {
                        JOptionPane.showMessageDialog(null,
                                "Número máximo de times cadastrados", "Mensagem",
                                JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        try {
                            fachada.adicionarTime(TimesPreExistentes.getTimeVermelho());
                            comboBoxTimes.addItem("timeVermelho");
                            num++;
                        } catch (TimeJaExistenteException ex) {
                            JOptionPane.showMessageDialog(null,
                                    "Time já adicionado", "Mensagem",
                                    JOptionPane.INFORMATION_MESSAGE);
                        }
                    }
                    timeVermelho.setSelected(false);
                }
            }
        });
    }
}